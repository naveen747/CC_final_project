db.createUser(
        {
            user: "someone",
            pwd: "nohint",
            roles: [
                {
                    role: "readWrite",
                    db: "mymongodb"
                }
            ]
        }
);